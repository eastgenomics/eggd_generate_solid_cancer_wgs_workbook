.. _api_io:

============
Input/Output
============

.. contents::

vcfpy.Reader
------------

.. autoclass:: vcfpy.Reader
    :members:

vcfpy.Writer
------------

.. autoclass:: vcfpy.Writer
    :members:
