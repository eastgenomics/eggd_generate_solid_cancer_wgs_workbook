.. _getting_started:


===============
Getting Started
===============

After installation, you can use VCFPy in your project simply by importing the module.

.. code-block:: python

    import vcfpy

That's all, continue and look at the list of examples.