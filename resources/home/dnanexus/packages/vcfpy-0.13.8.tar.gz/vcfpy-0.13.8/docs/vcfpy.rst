vcfpy package
=============

Submodules
----------

vcfpy.bgzf module
-----------------

.. automodule:: vcfpy.bgzf
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.exceptions module
-----------------------

.. automodule:: vcfpy.exceptions
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.header module
-------------------

.. automodule:: vcfpy.header
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.parser module
-------------------

.. automodule:: vcfpy.parser
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.reader module
-------------------

.. automodule:: vcfpy.reader
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.record module
-------------------

.. automodule:: vcfpy.record
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.warn_utils module
-----------------------

.. automodule:: vcfpy.warn_utils
    :members:
    :undoc-members:
    :show-inheritance:

vcfpy.writer module
-------------------

.. automodule:: vcfpy.writer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: vcfpy
    :members:
    :undoc-members:
    :show-inheritance:
