tests/vcfs

- from_vcf43.vcf: VCF header from VCFv4.3 standard
- from_vcf43.vcf.gz: VCF header from VCFv4.3 standard, bgzip-ed
- full_vcf43.vcf: full VCF file from VCFv4.3 standard
- full_vcf43.vcf.gz: full VCF file from VCFv4.3 standard, bgzip-ed