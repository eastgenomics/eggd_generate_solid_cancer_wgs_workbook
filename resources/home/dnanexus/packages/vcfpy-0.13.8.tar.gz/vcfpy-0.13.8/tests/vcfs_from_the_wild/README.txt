tests/vcfs_from_the_wild

This folder contains VCF files collected "from the wild", including VCF
files used for testing other VCF handling libraries.  Note that these files
may not be fully compliant so parsing them could throw warnings, but they
should be "OK" enough so they can be handled with a small amount of grace.